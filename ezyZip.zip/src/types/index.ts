export interface Student {
  id: string;
  name: string;
  grade: number;
  avatar: string;
  preferredLanguage: 'english' | 'hindi';
  assessmentCompleted: boolean;
  currentLevel: {
    math: number;
    english: number;
  };
  strengths: string[];
  weaknesses: string[];
  totalPoints: number;
  badges: Badge[];
  streakDays: number;
  createdAt: Date;
  lastActive: Date;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earnedAt: Date;
  category: 'math' | 'english' | 'general';
}

export interface Question {
  id: string;
  type: 'multiple-choice' | 'fill-blank' | 'drag-drop' | 'true-false';
  subject: 'math' | 'english';
  grade: number;
  difficulty: 'easy' | 'medium' | 'hard';
  question: string;
  options?: string[];
  correctAnswer: string | number;
  explanation: string;
  topic: string;
  hindiQuestion?: string;
  hindiOptions?: string[];
  points: number;
}

export interface LearningActivity {
  id: string;
  title: string;
  description: string;
  type: 'practice' | 'game' | 'story' | 'challenge';
  subject: 'math' | 'english';
  grade: number;
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedTime: number;
  points: number;
  requirements: string[];
  content: ActivityContent;
  hindiTitle?: string;
  hindiDescription?: string;
}

export interface ActivityContent {
  instructions: string;
  examples?: string[];
  questions?: Question[];
  story?: string;
  gameData?: any;
  hindiInstructions?: string;
}

export interface LearningPlan {
  id: string;
  studentId: string;
  week: number;
  year: number;
  activities: LearningActivity[];
  goals: string[];
  focus: string[];
  progress: {
    completed: number;
    total: number;
    points: number;
  };
  createdAt: Date;
}

export interface Assessment {
  id: string;
  studentId: string;
  subject: 'math' | 'english';
  grade: number;
  questions: Question[];
  answers: (string | number)[];
  score: number;
  completedAt: Date;
  recommendations: string[];
  identifiedGaps: string[];
}