import React from 'react';
import { Home, User, BookOpen, Trophy, Settings, Heart } from 'lucide-react';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  student: any;
}

const Navigation: React.FC<NavigationProps> = ({ currentPage, onNavigate, student }) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home, hindi: 'होम' },
    { id: 'assessment', label: 'Assessment', icon: BookOpen, hindi: 'मूल्यांकन' },
    { id: 'learning', label: 'Learning', icon: Heart, hindi: 'सीखना' },
    { id: 'progress', label: 'Progress', icon: Trophy, hindi: 'प्रगति' },
    { id: 'profile', label: 'Profile', icon: User, hindi: 'प्रोफाइल' }
  ];

  return (
    <nav className="bg-white shadow-lg border-t-4 border-orange-400">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">AI</span>
            </div>
            <h1 className="text-xl font-bold text-gray-800">Learning Coach</h1>
          </div>
          
          <div className="flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex flex-col items-center px-3 py-2 rounded-lg transition-all duration-200 ${
                    isActive
                      ? 'bg-orange-100 text-orange-600 shadow-sm'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-800'
                  }`}
                >
                  <Icon size={20} />
                  <span className="text-xs mt-1 font-medium">
                    {student?.preferredLanguage === 'hindi' ? item.hindi : item.label}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-yellow-800 text-xs font-bold">⭐</span>
              </div>
              <span className="font-semibold text-gray-700">{student?.totalPoints || 0}</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-2xl">{student?.avatar || '👦'}</span>
              <span className="font-medium text-gray-700">{student?.name || 'Student'}</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;