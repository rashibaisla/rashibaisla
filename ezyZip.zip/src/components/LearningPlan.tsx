import React, { useState } from 'react';
import { Calendar, Clock, Star, Play, CheckCircle, Award, Target } from 'lucide-react';
import { Student, LearningActivity } from '../types';
import { sampleActivities } from '../data/mockData';

interface LearningPlanProps {
  student: Student;
  onNavigate: (page: string) => void;
}

const LearningPlan: React.FC<LearningPlanProps> = ({ student, onNavigate }) => {
  const [selectedDay, setSelectedDay] = useState(0);
  const [completedActivities, setCompletedActivities] = useState<string[]>([]);

  const isHindi = student.preferredLanguage === 'hindi';

  const weekDays = [
    { name: isHindi ? 'सोमवार' : 'Monday', date: '21 Oct', activities: 3 },
    { name: isHindi ? 'मंगलवार' : 'Tuesday', date: '22 Oct', activities: 2 },
    { name: isHindi ? 'बुधवार' : 'Wednesday', date: '23 Oct', activities: 4 },
    { name: isHindi ? 'गुरुवार' : 'Thursday', date: '24 Oct', activities: 3 },
    { name: isHindi ? 'शुक्रवार' : 'Friday', date: '25 Oct', activities: 2 },
    { name: isHindi ? 'शनिवार' : 'Saturday', date: '26 Oct', activities: 2 },
    { name: isHindi ? 'रविवार' : 'Sunday', date: '27 Oct', activities: 1 }
  ];

  const getdailyActivities = {
    0: [ // Monday
      {
        ...sampleActivities[0],
        title: isHindi ? 'पिज़्ज़ा फ्रैक्शन मज़ा' : 'Pizza Fraction Fun',
        description: isHindi ? 'पिज़्ज़ा को काटकर भिन्न सीखें' : 'Learn fractions by cutting pizzas',
        completed: false
      },
      {
        id: 'math-addition',
        title: isHindi ? 'मजेदार जोड़ना' : 'Fun Addition',
        description: isHindi ? 'बड़ी संख्याओं को जोड़ना सीखें' : 'Learn to add bigger numbers',
        type: 'practice' as const,
        subject: 'math' as const,
        grade: 3,
        difficulty: 'medium' as const,
        estimatedTime: 10,
        points: 15,
        requirements: ['Basic addition'],
        content: {
          instructions: 'Solve addition problems step by step',
          hindiInstructions: 'जोड़ने के प्रश्नों को चरणबद्ध तरीके से हल करें'
        },
        completed: false
      },
      {
        id: 'english-reading',
        title: isHindi ? 'कहानी का समय' : 'Story Time',
        description: isHindi ? 'एक रोमांचक कहानी पढ़ें' : 'Read an exciting story',
        type: 'story' as const,
        subject: 'english' as const,
        grade: 3,
        difficulty: 'easy' as const,
        estimatedTime: 15,
        points: 20,
        requirements: ['Basic reading'],
        content: {
          instructions: 'Read the story and answer questions',
          story: 'Once upon a time, in a small village...',
          hindiInstructions: 'कहानी पढ़ें और प्रश्नों के उत्तर दें'
        },
        completed: false
      }
    ],
    1: [ // Tuesday
      {
        id: 'math-subtraction',
        title: isHindi ? 'घटाना मास्टर' : 'Subtraction Master',
        description: isHindi ? 'घटाने के तरीके सीखें' : 'Learn subtraction methods',
        type: 'practice' as const,
        subject: 'math' as const,
        grade: 3,
        difficulty: 'medium' as const,
        estimatedTime: 12,
        points: 15,
        requirements: ['Basic subtraction'],
        content: {
          instructions: 'Practice subtraction with borrowing',
          hindiInstructions: 'उधार लेकर घटाने का अभ्यास करें'
        },
        completed: false
      },
      {
        id: 'english-grammar',
        title: isHindi ? 'व्याकरण की खोज' : 'Grammar Explorer',
        description: isHindi ? 'संज्ञा और क्रिया सीखें' : 'Learn nouns and verbs',
        type: 'practice' as const,
        subject: 'english' as const,
        grade: 3,
        difficulty: 'medium' as const,
        estimatedTime: 15,
        points: 20,
        requirements: ['Basic grammar'],
        content: {
          instructions: 'Identify nouns and verbs in sentences',
          hindiInstructions: 'वाक्यों में संज्ञा और क्रिया की पहचान करें'
        },
        completed: false
      }
    ]
  };

  const handleCompleteActivity = (activityId: string) => {
    setCompletedActivities([...completedActivities, activityId]);
  };

  const dailyActivities:
  LearningActivity[][]=[
    sampleActivities,
    [],
  ] 
  const currentActivities = dailyActivities[selectedDay] || [];
  const completedToday = currentActivities.filter((activity: { id: string; }) => 
    completedActivities.includes(activity.id)
  ).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="bg-white rounded-2xl p-6 shadow-lg mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                {isHindi ? 'आपकी सीखने की योजना' : 'Your Learning Plan'}
              </h1>
              <p className="text-gray-600">
                {isHindi 
                  ? 'सप्ताह 1 - मौलिक कौशल निर्माण'
                  : 'Week 1 - Building Foundation Skills'
                }
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-indigo-600">{completedToday}</div>
                <div className="text-sm text-gray-600">
                  {isHindi ? 'आज पूरा' : 'Completed Today'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{student.streakDays}</div>
                <div className="text-sm text-gray-600">
                  {isHindi ? 'दिन स्ट्रीक' : 'Day Streak'}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Week Calendar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                {isHindi ? 'सप्ताह का कैलेंडर' : 'Week Calendar'}
              </h2>
              <div className="space-y-2">
                {weekDays.map((day, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedDay(index)}
                    className={`w-full p-4 rounded-lg text-left transition-all duration-200 ${
                      selectedDay === index
                        ? 'bg-indigo-100 border-2 border-indigo-500 text-indigo-800'
                        : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-semibold">{day.name}</div>
                        <div className="text-sm text-gray-600">{day.date}</div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center space-x-1">
                          <Calendar size={16} className="text-gray-400" />
                          <span className="text-sm text-gray-600">{day.activities}</span>
                        </div>
                        {index === 0 && (
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Daily Activities */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">
                  {weekDays[selectedDay].name} {isHindi ? 'की गतिविधियां' : 'Activities'}
                </h2>
                <div className="flex items-center space-x-2">
                  <Target size={20} className="text-indigo-600" />
                  <span className="text-sm font-medium text-gray-600">
                    {isHindi ? 'दैनिक लक्ष्य' : 'Daily Goal'}
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                {currentActivities.map((activity: { id: string; hindiTitle: any; title: any; hindiDescription: any; description: any; subject: string; type: string; estimatedTime: string | number | bigint | boolean | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | null | undefined; points: string | number | bigint | boolean | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | null | undefined; difficulty: string; }, index: React.Key | null | undefined) => {
                  const isCompleted = completedActivities.includes(activity.id);
                  const activityTitle = isHindi && activity.hindiTitle ? activity.hindiTitle : activity.title;
                  const activityDescription = isHindi && activity.hindiDescription ? activity.hindiDescription : activity.description;

                  return (
                    <div
                      key={index}
                      className={`p-6 rounded-lg border-2 transition-all duration-200 ${
                        isCompleted
                          ? 'bg-green-50 border-green-200'
                          : 'bg-gray-50 border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              activity.subject === 'math' ? 'bg-blue-100' : 'bg-green-100'
                            }`}>
                              <span className="text-2xl">
                                {activity.type === 'game' ? '🎮' : 
                                 activity.type === 'story' ? '📖' : 
                                 activity.subject === 'math' ? '🔢' : '✏️'}
                              </span>
                            </div>
                            <div>
                              <h3 className="font-semibold text-gray-800">{activityTitle}</h3>
                              <p className="text-sm text-gray-600">{activityDescription}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <div className="flex items-center space-x-1">
                              <Clock size={14} />
                              <span>{activity.estimatedTime} {isHindi ? 'मिनट' : 'min'}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Star size={14} />
                              <span>+{activity.points} {isHindi ? 'अंक' : 'points'}</span>
                            </div>
                            <div className="px-2 py-1 bg-gray-200 rounded-full text-xs">
                              {activity.difficulty === 'easy' ? (isHindi ? 'आसान' : 'Easy') :
                               activity.difficulty === 'medium' ? (isHindi ? 'मध्यम' : 'Medium') :
                               (isHindi ? 'कठिन' : 'Hard')}
                            </div>
                          </div>
                        </div>
                        
                        <div className="ml-4">
                          {isCompleted ? (
                            <div className="flex items-center space-x-2 text-green-600">
                              <CheckCircle size={20} />
                              <span className="text-sm font-medium">
                                {isHindi ? 'पूरा' : 'Complete'}
                              </span>
                            </div>
                          ) : (
                            <button
                              onClick={() => handleCompleteActivity(activity.id)}
                              className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                            >
                              <Play size={16} />
                              <span className="text-sm font-medium">
                                {isHindi ? 'शुरू करें' : 'Start'}
                              </span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Achievement Section */}
              {completedToday > 0 && (
                <div className="mt-6 p-4 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Award size={24} className="text-green-600" />
                    <div>
                      <h3 className="font-semibold text-gray-800">
                        {isHindi ? 'बहुत बढ़िया!' : 'Great Job!'}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {isHindi 
                          ? `आपने आज ${completedToday} गतिविधि पूरी की है!`
                          : `You've completed ${completedToday} activities today!`
                        }
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearningPlan;