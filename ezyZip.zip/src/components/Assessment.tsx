import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Clock, Target, CheckCircle } from 'lucide-react';
import { Question, Student } from '../types';
import { assessmentQuestions } from '../data/mockData';

interface AssessmentProps {
  student: Student;
  onComplete: (results: any) => void;
  onNavigate: (page: string) => void;
}

const Assessment: React.FC<AssessmentProps> = ({ student, onComplete, onNavigate }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<(string | number)[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [isStarted, setIsStarted] = useState(false);

  const isHindi = student.preferredLanguage === 'hindi';
  const questions = assessmentQuestions;

  const handleStart = () => {
    setIsStarted(true);
  };

  const handleAnswer = (answer: string) => {
    setSelectedAnswer(answer);
  };

  const handleNext = () => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedAnswer;
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer('');
    } else {
      // Calculate score and show results
      const correctAnswers = questions.filter((q, index) => q.correctAnswer === newAnswers[index]).length;
      const totalScore = (correctAnswers / questions.length) * 100;
      setScore(totalScore);
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedAnswer(answers[currentQuestion - 1]?.toString() || '');
    }
  };

  const handleCompleteAssessment = () => {
    const results = {
      score,
      answers,
      identifiedGaps: score < 70 ? ['Basic Math', 'Grammar'] : [],
      recommendations: score < 70 ? ['Practice fractions', 'Review grammar rules'] : ['Continue with current level']
    };
    onComplete(results);
    onNavigate('home');
  };

  if (!isStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center">
        <div className="max-w-2xl mx-auto p-8">
          <div className="bg-white rounded-2xl p-8 shadow-xl">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Target size={40} className="text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                {isHindi ? 'आकलन शुरू करें' : 'Start Your Assessment'}
              </h2>
              <p className="text-gray-600 mb-6 text-lg">
                {isHindi 
                  ? 'यह आकलन आपकी वर्तमान स्किल्स को समझने में मदद करेगा और व्यक्तिगत सीखने की योजना बनाएगा।'
                  : 'This assessment will help understand your current skills and create a personalized learning plan.'
                }
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="text-blue-600 font-semibold">
                    {isHindi ? '5 प्रश्न' : '5 Questions'}
                  </div>
                  <div className="text-sm text-gray-600">
                    {isHindi ? 'मिश्रित विषय' : 'Mixed Topics'}
                  </div>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="text-green-600 font-semibold">
                    {isHindi ? '~10 मिनट' : '~10 Minutes'}
                  </div>
                  <div className="text-sm text-gray-600">
                    {isHindi ? 'अनुमानित समय' : 'Estimated Time'}
                  </div>
                </div>
                <div className="p-4 bg-orange-50 rounded-lg">
                  <div className="text-orange-600 font-semibold">
                    {isHindi ? 'व्यक्तिगत' : 'Personalized'}
                  </div>
                  <div className="text-sm text-gray-600">
                    {isHindi ? 'आपके लिए' : 'Just for You'}
                  </div>
                </div>
              </div>
              <button
                onClick={handleStart}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-4 px-8 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl text-lg"
              >
                {isHindi ? 'आकलन शुरू करें' : 'Start Assessment'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (showResults) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center">
        <div className="max-w-2xl mx-auto p-8">
          <div className="bg-white rounded-2xl p-8 shadow-xl">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={40} className="text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                {isHindi ? 'आकलन पूरा!' : 'Assessment Complete!'}
              </h2>
              <div className="text-6xl font-bold text-green-600 mb-4">
                {Math.round(score)}%
              </div>
              <p className="text-gray-600 mb-6 text-lg">
                {isHindi 
                  ? 'बहुत बढ़िया! आपके परिणामों के आधार पर हमने आपके लिए एक व्यक्तिगत सीखने की योजना तैयार की है।'
                  : 'Great job! Based on your results, we\'ve created a personalized learning plan for you.'
                }
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="p-6 bg-green-50 rounded-lg">
                  <h3 className="font-bold text-green-800 mb-2">
                    {isHindi ? 'मजबूत क्षेत्र' : 'Strong Areas'}
                  </h3>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• {isHindi ? 'जोड़ना' : 'Addition'}</li>
                    <li>• {isHindi ? 'पढ़ना' : 'Reading'}</li>
                    <li>• {isHindi ? 'आकार' : 'Shapes'}</li>
                  </ul>
                </div>
                <div className="p-6 bg-orange-50 rounded-lg">
                  <h3 className="font-bold text-orange-800 mb-2">
                    {isHindi ? 'सुधार के क्षेत्र' : 'Areas to Improve'}
                  </h3>
                  <ul className="text-sm text-orange-700 space-y-1">
                    <li>• {isHindi ? 'भिन्न' : 'Fractions'}</li>
                    <li>• {isHindi ? 'व्याकरण' : 'Grammar'}</li>
                    <li>• {isHindi ? 'वाक्य निर्माण' : 'Sentence Building'}</li>
                  </ul>
                </div>
              </div>

              <button
                onClick={handleCompleteAssessment}
                className="bg-gradient-to-r from-green-500 to-blue-600 text-white font-bold py-4 px-8 rounded-xl hover:from-green-600 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl text-lg"
              >
                {isHindi ? 'मेरी सीखने की योजना देखें' : 'View My Learning Plan'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-600">
              {isHindi ? 'प्रगति' : 'Progress'}
            </span>
            <span className="text-sm font-medium text-gray-600">
              {currentQuestion + 1} / {questions.length}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-2xl p-8 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">{currentQuestion + 1}</span>
              </div>
              <span className="text-lg font-semibold text-gray-800 capitalize">
                {question.subject} • {question.topic}
              </span>
            </div>
            <div className="flex items-center space-x-2 text-gray-600">
              <Clock size={16} />
              <span className="text-sm">{question.points} {isHindi ? 'अंक' : 'points'}</span>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-gray-800 mb-8">
            {isHindi && question.hindiQuestion ? question.hindiQuestion : question.question}
          </h2>

          {/* Multiple Choice Options */}
          {question.type === 'multiple-choice' && (
            <div className="grid grid-cols-1 gap-4 mb-8">
              {question.options?.map((option, index) => {
                const optionText = isHindi && question.hindiOptions ? question.hindiOptions[index] : option;
                return (
                  <button
                    key={index}
                    onClick={() => handleAnswer(option)}
                    className={`p-4 rounded-lg border-2 text-left transition-all duration-200 ${
                      selectedAnswer === option
                        ? 'border-purple-500 bg-purple-50 text-purple-800'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        selectedAnswer === option
                          ? 'border-purple-500 bg-purple-500'
                          : 'border-gray-300'
                      }`}>
                        {selectedAnswer === option && (
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        )}
                      </div>
                      <span className="text-lg">{optionText}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between items-center">
            <button
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-all duration-200 ${
                currentQuestion === 0
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
              }`}
            >
              <ChevronLeft size={20} />
              <span>{isHindi ? 'पिछला' : 'Previous'}</span>
            </button>

            <button
              onClick={handleNext}
              disabled={!selectedAnswer}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-all duration-200 ${
                selectedAnswer
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600 shadow-lg'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              <span>{currentQuestion === questions.length - 1 ? (isHindi ? 'समाप्त' : 'Finish') : (isHindi ? 'अगला' : 'Next')}</span>
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Assessment;