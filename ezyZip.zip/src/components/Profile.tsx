import React, { useState } from 'react';
import { User, Settings, Globe, Bell, BookOpen, Award, Calendar, Heart } from 'lucide-react';
import { Student } from '../types';

interface ProfileProps {
  student: Student;
  onUpdateStudent: (student: Student) => void;
}

const Profile: React.FC<ProfileProps> = ({ student, onUpdateStudent }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedStudent, setEditedStudent] = useState(student);

  const isHindi = student.preferredLanguage === 'hindi';

  const handleSave = () => {
    onUpdateStudent(editedStudent);
    setIsEditing(false);
  };

  const handleLanguageChange = (language: 'english' | 'hindi') => {
    const updated = { ...editedStudent, preferredLanguage: language };
    setEditedStudent(updated);
    onUpdateStudent(updated);
  };

  const avatarOptions = ['👦', '👧', '🧒', '👨‍🎓', '👩‍🎓', '🤓', '😊', '🌟'];

  const profileStats = [
    {
      icon: Calendar,
      label: isHindi ? 'सदस्य बने' : 'Member Since',
      value: student.createdAt.toLocaleDateString(),
      color: 'text-blue-600 bg-blue-100'
    },
    {
      icon: Award,
      label: isHindi ? 'कुल बैज' : 'Total Badges',
      value: student.badges.length,
      color: 'text-yellow-600 bg-yellow-100'
    },
    {
      icon: BookOpen,
      label: isHindi ? 'पूरे किए गए' : 'Completed',
      value: '24 activities',
      color: 'text-green-600 bg-green-100'
    },
    {
      icon: Heart,
      label: isHindi ? 'पसंदीदा विषय' : 'Favorite Subject',
      value: isHindi ? 'गणित' : 'Mathematics',
      color: 'text-pink-600 bg-pink-100'
    }
  ];

  const preferences = [
    {
      id: 'notifications',
      label: isHindi ? 'सूचनाएं' : 'Notifications',
      description: isHindi ? 'दैनिक रिमाइंडर प्राप्त करें' : 'Receive daily reminders',
      enabled: true
    },
    {
      id: 'sounds',
      label: isHindi ? 'आवाज़' : 'Sounds',
      description: isHindi ? 'गेम और गतिविधियों में आवाज़' : 'Sound effects in games and activities',
      enabled: true
    },
    {
      id: 'offline',
      label: isHindi ? 'ऑफ़लाइन मोड' : 'Offline Mode',
      description: isHindi ? 'इंटरनेट के बिना सीखें' : 'Learn without internet',
      enabled: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="bg-white rounded-2xl p-8 shadow-lg mb-8">
          <div className="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-8">
            <div className="relative">
              <div className="w-32 h-32 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center text-6xl shadow-lg">
                {isEditing ? (
                  <select
                    value={editedStudent.avatar}
                    onChange={(e) => setEditedStudent({...editedStudent, avatar: e.target.value})}
                    className="w-full h-full bg-transparent text-6xl text-center border-none outline-none"
                  >
                    {avatarOptions.map((avatar, index) => (
                      <option key={index} value={avatar}>{avatar}</option>
                    ))}
                  </select>
                ) : (
                  student.avatar
                )}
              </div>
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-bold">
                {student.currentLevel.math}
              </div>
            </div>
            
            <div className="flex-1 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start space-x-4 mb-4">
                {isEditing ? (
                  <input
                    type="text"
                    value={editedStudent.name}
                    onChange={(e) => setEditedStudent({...editedStudent, name: e.target.value})}
                    className="text-3xl font-bold text-gray-800 bg-transparent border-b-2 border-purple-500 outline-none"
                  />
                ) : (
                  <h1 className="text-3xl font-bold text-gray-800">{student.name}</h1>
                )}
                <button
                  onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm"
                >
                  {isEditing ? (isHindi ? 'सेव' : 'Save') : (isHindi ? 'एडिट' : 'Edit')}
                </button>
              </div>
              
              <div className="flex items-center justify-center md:justify-start space-x-4 mb-4">
                <div className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                  {isHindi ? `कक्षा ${student.grade}` : `Grade ${student.grade}`}
                </div>
                <div className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">
                  {student.streakDays} {isHindi ? 'दिन स्ट्रीक' : 'day streak'}
                </div>
              </div>
              
              <p className="text-gray-600 mb-4">
                {isHindi 
                  ? 'गणित और अंग्रेजी में उत्साही शिक्षार्थी। सीखने के लिए हमेशा तैयार!'
                  : 'Enthusiastic learner in Math and English. Always ready to learn!'
                }
              </p>
              
              <div className="flex items-center justify-center md:justify-start space-x-2">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                    <span className="text-yellow-800 text-xs font-bold">⭐</span>
                  </div>
                  <span className="font-semibold text-gray-700">{student.totalPoints} {isHindi ? 'अंक' : 'points'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {profileStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${stat.color}`}>
                    <Icon size={20} />
                  </div>
                </div>
                <div className="text-lg font-bold text-gray-800 mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-gray-600">
                  {stat.label}
                </div>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Language Settings */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
              <Globe size={24} className="mr-2" />
              {isHindi ? 'भाषा सेटिंग्स' : 'Language Settings'}
            </h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-semibold text-gray-800">English</h3>
                  <p className="text-sm text-gray-600">Learn in English</p>
                </div>
                <button
                  onClick={() => handleLanguageChange('english')}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    student.preferredLanguage === 'english' ? 'bg-purple-600' : 'bg-gray-300'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                    student.preferredLanguage === 'english' ? 'translate-x-6' : 'translate-x-1'
                  }`}></div>
                </button>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-semibold text-gray-800">हिंदी</h3>
                  <p className="text-sm text-gray-600">हिंदी में सीखें</p>
                </div>
                <button
                  onClick={() => handleLanguageChange('hindi')}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    student.preferredLanguage === 'hindi' ? 'bg-purple-600' : 'bg-gray-300'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                    student.preferredLanguage === 'hindi' ? 'translate-x-6' : 'translate-x-1'
                  }`}></div>
                </button>
              </div>
            </div>
          </div>

          {/* App Preferences */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
              <Settings size={24} className="mr-2" />
              {isHindi ? 'ऐप प्राथमिकताएं' : 'App Preferences'}
            </h2>
            
            <div className="space-y-4">
              {preferences.map((pref, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h3 className="font-semibold text-gray-800">{pref.label}</h3>
                    <p className="text-sm text-gray-600">{pref.description}</p>
                  </div>
                  <button
                    className={`w-12 h-6 rounded-full transition-colors ${
                      pref.enabled ? 'bg-purple-600' : 'bg-gray-300'
                    }`}
                  >
                    <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      pref.enabled ? 'translate-x-6' : 'translate-x-1'
                    }`}></div>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Strengths and Weaknesses */}
        <div className="mt-8 bg-white rounded-2xl p-6 shadow-lg">
          <h2 className="text-xl font-bold text-gray-800 mb-6">
            {isHindi ? 'मजबूत और कमजोर क्षेत्र' : 'Strengths and Areas for Improvement'}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-green-800 mb-3 flex items-center">
                <Award size={20} className="mr-2" />
                {isHindi ? 'मजबूत क्षेत्र' : 'Strengths'}
              </h3>
              <div className="space-y-2">
                {student.strengths.map((strength, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 bg-green-50 rounded-lg">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-green-800">{strength}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-orange-800 mb-3 flex items-center">
                <BookOpen size={20} className="mr-2" />
                {isHindi ? 'सुधार के क्षेत्र' : 'Areas for Improvement'}
              </h3>
              <div className="space-y-2">
                {student.weaknesses.map((weakness, index) => (
                  <div key={index} className="flex items-center space-x-2 p-2 bg-orange-50 rounded-lg">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span className="text-orange-800">{weakness}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;