import React, { useState } from 'react';
import { TrendingUp, Award, Calendar, Star, Target, Trophy, Clock, BookOpen } from 'lucide-react';
import { Student } from '../types';
import { achievements } from '../data/mockData';

interface ProgressProps {
  student: Student;
}

const Progress: React.FC<ProgressProps> = ({ student }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  const isHindi = student.preferredLanguage === 'hindi';

  const progressData = {
    week: {
      math: [60, 65, 70, 75, 80, 85, 90],
      english: [70, 73, 76, 80, 82, 85, 88],
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    },
    month: {
      math: [60, 70, 75, 85],
      english: [70, 75, 80, 88],
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4']
    }
  };

  const currentData = progressData[selectedPeriod];

  const stats = [
    {
      icon: Star,
      label: isHindi ? 'कुल अंक' : 'Total Points',
      value: student.totalPoints,
      change: '+25',
      color: 'text-yellow-600 bg-yellow-100'
    },
    {
      icon: Trophy,
      label: isHindi ? 'अर्जित बैज' : 'Badges Earned',
      value: student.badges.length,
      change: '+2',
      color: 'text-blue-600 bg-blue-100'
    },
    {
      icon: Target,
      label: isHindi ? 'लक्ष्य पूरे' : 'Goals Completed',
      value: 12,
      change: '+3',
      color: 'text-green-600 bg-green-100'
    },
    {
      icon: Clock,
      label: isHindi ? 'सीखने का समय' : 'Learning Time',
      value: '4.5h',
      change: '+1.2h',
      color: 'text-purple-600 bg-purple-100'
    }
  ];

  const subjects = [
    {
      name: isHindi ? 'गणित' : 'Mathematics',
      icon: '🔢',
      currentLevel: student.currentLevel.math,
      progress: 85,
      color: 'blue',
      topics: [
        { name: isHindi ? 'जोड़ना' : 'Addition', mastery: 95 },
        { name: isHindi ? 'घटाना' : 'Subtraction', mastery: 88 },
        { name: isHindi ? 'भिन्न' : 'Fractions', mastery: 65 },
        { name: isHindi ? 'आकार' : 'Shapes', mastery: 92 }
      ]
    },
    {
      name: isHindi ? 'अंग्रेजी' : 'English',
      icon: '📚',
      currentLevel: student.currentLevel.english,
      progress: 88,
      color: 'green',
      topics: [
        { name: isHindi ? 'पढ़ना' : 'Reading', mastery: 92 },
        { name: isHindi ? 'व्याकरण' : 'Grammar', mastery: 78 },
        { name: isHindi ? 'लेखन' : 'Writing', mastery: 85 },
        { name: isHindi ? 'शब्दावली' : 'Vocabulary', mastery: 88 }
      ]
    }
  ];

  const recentAchievements = achievements.slice(0, 3);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="bg-white rounded-2xl p-6 shadow-lg mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                {isHindi ? 'आपकी प्रगति' : 'Your Progress'}
              </h1>
              <p className="text-gray-600">
                {isHindi 
                  ? 'देखें कि आपने कितनी अच्छी प्रगति की है!'
                  : 'See how well you\'ve been doing!'
                }
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setSelectedPeriod('week')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  selectedPeriod === 'week'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {isHindi ? 'सप्ताह' : 'Week'}
              </button>
              <button
                onClick={() => setSelectedPeriod('month')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  selectedPeriod === 'month'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {isHindi ? 'महीना' : 'Month'}
              </button>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${stat.color}`}>
                    <Icon size={24} />
                  </div>
                  <div className="text-green-600 text-sm font-medium">
                    {stat.change}
                  </div>
                </div>
                <div className="text-2xl font-bold text-gray-800 mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-gray-600">
                  {stat.label}
                </div>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Subject Progress */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h2 className="text-xl font-bold text-gray-800 mb-6">
              {isHindi ? 'विषय की प्रगति' : 'Subject Progress'}
            </h2>
            <div className="space-y-6">
              {subjects.map((subject, index) => (
                <div key={index} className="border-b border-gray-100 pb-6 last:border-b-0 last:pb-0">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{subject.icon}</span>
                      <div>
                        <h3 className="font-semibold text-gray-800">{subject.name}</h3>
                        <p className="text-sm text-gray-600">
                          {isHindi ? `स्तर ${subject.currentLevel}` : `Level ${subject.currentLevel}`}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-gray-800">{subject.progress}%</div>
                      <div className="text-sm text-gray-600">
                        {isHindi ? 'पूरा' : 'Complete'}
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                    <div
                      className={`h-2 rounded-full ${
                        subject.color === 'blue' ? 'bg-blue-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${subject.progress}%` }}
                    ></div>
                  </div>

                  <div className="space-y-2">
                    {subject.topics.map((topic, topicIndex) => (
                      <div key={topicIndex} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">{topic.name}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-16 bg-gray-200 rounded-full h-1">
                            <div
                              className={`h-1 rounded-full ${
                                topic.mastery >= 90 ? 'bg-green-500' :
                                topic.mastery >= 70 ? 'bg-yellow-500' : 'bg-orange-500'
                              }`}
                              style={{ width: `${topic.mastery}%` }}
                            ></div>
                          </div>
                          <span className="text-xs text-gray-500 w-8">{topic.mastery}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Achievements */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h2 className="text-xl font-bold text-gray-800 mb-6">
              {isHindi ? 'हाल की उपलब्धियां' : 'Recent Achievements'}
            </h2>
            <div className="space-y-4">
              {recentAchievements.map((achievement, index) => (
                <div key={index} className="flex items-center space-x-4 p-4 bg-gradient-to-r from-orange-50 to-pink-50 rounded-lg">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center">
                    <span className="text-2xl">{achievement.icon}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800">{achievement.name}</h3>
                    <p className="text-sm text-gray-600">{achievement.description}</p>
                  </div>
                  <div className="text-xs text-gray-500">
                    {isHindi ? 'अभी' : 'Now'}
                  </div>
                </div>
              ))}
            </div>

            {/* All Badges */}
            <div className="mt-6 pt-6 border-t border-gray-100">
              <h3 className="font-semibold text-gray-800 mb-4">
                {isHindi ? 'सभी बैज' : 'All Badges'}
              </h3>
              <div className="grid grid-cols-5 gap-3">
                {achievements.map((badge, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mb-1">
                      <span className="text-lg">{badge.icon}</span>
                    </div>
                    <span className="text-xs text-gray-600 text-center leading-tight">
                      {badge.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Progress Chart Visualization */}
        <div className="mt-8 bg-white rounded-2xl p-6 shadow-lg">
          <h2 className="text-xl font-bold text-gray-800 mb-6">
            {isHindi ? 'प्रगति चार्ट' : 'Progress Chart'}
          </h2>
          <div className="h-64 flex items-end justify-between space-x-2">
            {currentData.labels.map((label, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div className="w-full flex flex-col items-center space-y-1 mb-2">
                  <div className="w-full bg-blue-100 rounded-t-lg relative" style={{ height: `${currentData.math[index]}%` }}>
                    <div className="absolute top-0 left-0 w-full h-full bg-blue-500 rounded-t-lg opacity-80"></div>
                  </div>
                  <div className="w-full bg-green-100 rounded-t-lg relative" style={{ height: `${currentData.english[index]}%` }}>
                    <div className="absolute top-0 left-0 w-full h-full bg-green-500 rounded-t-lg opacity-80"></div>
                  </div>
                </div>
                <span className="text-xs text-gray-600">{label}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-center space-x-6 mt-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm text-gray-600">
                {isHindi ? 'गणित' : 'Math'}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-sm text-gray-600">
                {isHindi ? 'अंग्रेजी' : 'English'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Progress;