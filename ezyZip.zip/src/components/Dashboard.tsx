import React from 'react';
import { BookOpen, Trophy, Target, Clock, Star, TrendingUp } from 'lucide-react';
import { Student } from '../types';

interface DashboardProps {
  student: Student;
  onNavigate: (page: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ student, onNavigate }) => {
  const isHindi = student.preferredLanguage === 'hindi';

  const quickStats = [
    {
      icon: Star,
      label: isHindi ? 'कुल अंक' : 'Total Points',
      value: student.totalPoints,
      color: 'text-yellow-600 bg-yellow-100'
    },
    {
      icon: TrendingUp,
      label: isHindi ? 'स्ट्रीक दिन' : 'Streak Days',
      value: student.streakDays,
      color: 'text-orange-600 bg-orange-100'
    },
    {
      icon: Trophy,
      label: isHindi ? 'बैज' : 'Badges',
      value: student.badges.length,
      color: 'text-blue-600 bg-blue-100'
    }
  ];

  const subjects = [
    {
      name: isHindi ? 'गणित' : 'Mathematics',
      level: student.currentLevel.math,
      progress: 75,
      icon: '🔢',
      color: 'bg-blue-500'
    },
    {
      name: isHindi ? 'अंग्रेजी' : 'English',
      level: student.currentLevel.english,
      progress: 85,
      icon: '📚',
      color: 'bg-green-500'
    }
  ];

  const todaysActivities = [
    {
      title: isHindi ? 'भिन्न का खेल' : 'Fraction Fun Game',
      time: '15 min',
      points: 20,
      type: 'game'
    },
    {
      title: isHindi ? 'कहानी पढ़ना' : 'Story Reading',
      time: '20 min',
      points: 25,
      type: 'story'
    },
    {
      title: isHindi ? 'व्याकरण अभ्यास' : 'Grammar Practice',
      time: '10 min',
      points: 15,
      type: 'practice'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-lg border-l-4 border-orange-400">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-800 mb-2">
                  {isHindi ? `नमस्ते ${student.name}!` : `Hello ${student.name}!`}
                </h2>
                <p className="text-gray-600">
                  {isHindi 
                    ? 'आज सीखने के लिए तैयार हैं? आइए शुरू करते हैं!'
                    : 'Ready to learn something amazing today? Let\'s get started!'
                  }
                </p>
              </div>
              <div className="text-6xl">{student.avatar}</div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {quickStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                    <p className="text-3xl font-bold text-gray-800">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${stat.color}`}>
                    <Icon size={24} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Subject Progress */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4">
              {isHindi ? 'विषय की प्रगति' : 'Subject Progress'}
            </h3>
            <div className="space-y-4">
              {subjects.map((subject, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{subject.icon}</span>
                      <div>
                        <h4 className="font-semibold text-gray-800">{subject.name}</h4>
                        <p className="text-sm text-gray-600">
                          {isHindi ? `स्तर ${subject.level}` : `Level ${subject.level}`}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-700">{subject.progress}%</p>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${subject.color}`}
                      style={{ width: `${subject.progress}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Today's Activities */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4">
              {isHindi ? 'आज की गतिविधियां' : 'Today\'s Activities'}
            </h3>
            <div className="space-y-3">
              {todaysActivities.map((activity, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-bold">
                        {activity.type === 'game' ? '🎮' : activity.type === 'story' ? '📖' : '✏️'}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">{activity.title}</h4>
                      <p className="text-sm text-gray-600">{activity.time}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-orange-600">+{activity.points}</span>
                    <Clock size={14} className="text-gray-400" />
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={() => onNavigate('learning')}
              className="w-full mt-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-semibold py-3 px-6 rounded-lg hover:from-orange-600 hover:to-pink-600 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              {isHindi ? 'सभी गतिविधियां देखें' : 'View All Activities'}
            </button>
          </div>
        </div>

        {/* Assessment CTA */}
        {!student.assessmentCompleted && (
          <div className="mt-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold mb-2">
                  {isHindi ? 'अपना मूल्यांकन पूरा करें' : 'Complete Your Assessment'}
                </h3>
                <p className="text-blue-100">
                  {isHindi 
                    ? 'व्यक्तिगत सीखने की योजना प्राप्त करने के लिए एक त्वरित मूल्यांकन लें'
                    : 'Take a quick assessment to get a personalized learning plan'
                  }
                </p>
              </div>
              <button
                onClick={() => onNavigate('assessment')}
                className="bg-white text-blue-600 font-semibold py-2 px-6 rounded-lg hover:bg-gray-100 transition-colors"
              >
                {isHindi ? 'शुरू करें' : 'Start Now'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;