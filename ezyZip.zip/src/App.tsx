import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import Assessment from './components/Assessment';
import LearningPlan from './components/LearningPlan';
import Progress from './components/Progress';
import Profile from './components/Profile';
import { Student } from './types';
import { sampleStudent } from './data/mockData';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [student, setStudent] = useState<Student>(sampleStudent);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudent(updatedStudent);
  };

  const handleAssessmentComplete = (results: any) => {
    setStudent({
      ...student,
      assessmentCompleted: true,
      totalPoints: student.totalPoints + 50,
      strengths: results.score > 70 ? ['Addition', 'Reading', 'Shapes'] : ['Basic Math'],
      weaknesses: results.identifiedGaps
    });
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <Dashboard student={student} onNavigate={handleNavigate} />;
      case 'assessment':
        return (
          <Assessment
            student={student}
            onComplete={handleAssessmentComplete}
            onNavigate={handleNavigate}
          />
        );
      case 'learning':
        return <LearningPlan student={student} onNavigate={handleNavigate} />;
      case 'progress':
        return <Progress student={student} />;
      case 'profile':
        return <Profile student={student} onUpdateStudent={handleUpdateStudent} />;
      default:
        return <Dashboard student={student} onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        currentPage={currentPage}
        onNavigate={handleNavigate}
        student={student}
      />
      <main>
        {renderCurrentPage()}
      </main>
    </div>
  );
}

export default App;