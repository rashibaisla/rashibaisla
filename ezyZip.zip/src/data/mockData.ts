import { Student, Question, LearningActivity, Badge } from '../types';

export const sampleStudent: Student = {
  id: '1',
  name: 'Priya Sharma',
  grade: 3,
  avatar: '👧',
  preferredLanguage: 'english',
  assessmentCompleted: false,
  currentLevel: {
    math: 2,
    english: 3
  },
  strengths: ['Addition', 'Reading Comprehension'],
  weaknesses: ['Fractions', 'Grammar'],
  totalPoints: 150,
  badges: [
    {
      id: '1',
      name: 'Math Explorer',
      description: 'Completed 10 math problems',
      icon: '🔢',
      earnedAt: new Date(),
      category: 'math'
    }
  ],
  streakDays: 5,
  createdAt: new Date(),
  lastActive: new Date()
};

export const assessmentQuestions: Question[] = [
  {
    id: '1',
    type: 'multiple-choice',
    subject: 'math',
    grade: 3,
    difficulty: 'easy',
    question: 'What is 25 + 17?',
    options: ['32', '42', '52', '62'],
    correctAnswer: '42',
    explanation: 'When we add 25 and 17, we get 42.',
    topic: 'Addition',
    hindiQuestion: '25 + 17 क्या है?',
    points: 10
  },
  {
    id: '2',
    type: 'multiple-choice',
    subject: 'math',
    grade: 3,
    difficulty: 'medium',
    question: 'Which fraction is bigger: 1/2 or 1/4?',
    options: ['1/2', '1/4', 'Both are equal', 'Cannot tell'],
    correctAnswer: '1/2',
    explanation: 'When we cut a pizza into 2 pieces, each piece is bigger than when we cut it into 4 pieces.',
    topic: 'Fractions',
    hindiQuestion: 'कौन सा भिन्न बड़ा है: 1/2 या 1/4?',
    points: 15
  },
  {
    id: '3',
    type: 'multiple-choice',
    subject: 'math',
    grade: 3,
    difficulty: 'easy',
    question: 'How many sides does a triangle have?',
    options: ['2', '3', '4', '5'],
    correctAnswer: '3',
    explanation: 'A triangle always has exactly 3 sides.',
    topic: 'Geometry',
    hindiQuestion: 'त्रिभुज की कितनी भुजाएं होती हैं?',
    points: 10
  },
  {
    id: '4',
    type: 'multiple-choice',
    subject: 'english',
    grade: 3,
    difficulty: 'easy',
    question: 'Which word is a noun?',
    options: ['run', 'beautiful', 'book', 'quickly'],
    correctAnswer: 'book',
    explanation: 'A noun is a person, place, or thing. Book is a thing.',
    topic: 'Parts of Speech',
    hindiQuestion: 'कौन सा शब्द संज्ञा है?',
    points: 10
  },
  {
    id: '5',
    type: 'multiple-choice',
    subject: 'english',
    grade: 3,
    difficulty: 'medium',
    question: 'What is the past tense of "go"?',
    options: ['goed', 'went', 'going', 'goes'],
    correctAnswer: 'went',
    explanation: 'The past tense of "go" is "went". Yesterday I went to school.',
    topic: 'Grammar',
    hindiQuestion: '"go" का भूतकाल क्या है?',
    points: 15
  }
];

export const sampleActivities: LearningActivity[] = [
  {
    id: '1',
    title: 'Pizza Fraction Fun',
    description: 'Learn about fractions by cutting pizzas into equal parts!',
    type: 'game',
    subject: 'math',
    grade: 3,
    difficulty: 'easy',
    estimatedTime: 15,
    points: 20,
    requirements: ['Basic understanding of parts and wholes'],
    content: {
      instructions: 'Cut the pizza into equal parts and identify the fractions',
      examples: ['1/2 means 1 out of 2 equal parts', '1/4 means 1 out of 4 equal parts'],
      hindiInstructions: 'पिज़्ज़ा को बराबर भागों में काटें और भिन्न की पहचान करें'
    },
    hindiTitle: 'पिज़्ज़ा फ्रैक्शन मज़ा',
    hindiDescription: 'पिज़्ज़ा को बराबर भागों में काटकर भिन्न सीखें!'
  },
  {
    id: '2',
    title: 'Animal Story Reading',
    description: 'Read a beautiful story about brave animals and answer questions',
    type: 'story',
    subject: 'english',
    grade: 3,
    difficulty: 'medium',
    estimatedTime: 20,
    points: 25,
    requirements: ['Basic reading skills'],
    content: {
      instructions: 'Read the story carefully and answer the questions',
      story: 'The Brave Little Mouse lived in a small hole near the kitchen. One day, she heard a cat crying for help. Even though she was scared, the little mouse decided to help...',
      hindiInstructions: 'कहानी को ध्यान से पढ़ें और प्रश्नों के उत्तर दें'
    },
    hindiTitle: 'जानवरों की कहानी पढ़ना',
    hindiDescription: 'बहादुर जानवरों के बारे में एक सुंदर कहानी पढ़ें और प्रश्नों के उत्तर दें'
  }
];

export const achievements: Badge[] = [
  {
    id: '1',
    name: 'Math Explorer',
    description: 'Completed 10 math problems',
    icon: '🔢',
    earnedAt: new Date(),
    category: 'math'
  },
  {
    id: '2',
    name: 'Reading Champion',
    description: 'Read 5 stories',
    icon: '📚',
    earnedAt: new Date(),
    category: 'english'
  },
  {
    id: '3',
    name: 'Streak Master',
    description: 'Learned for 7 days in a row',
    icon: '🔥',
    earnedAt: new Date(),
    category: 'general'
  },
  {
    id: '4',
    name: 'Fraction Master',
    description: 'Mastered fraction basics',
    icon: '🍕',
    earnedAt: new Date(),
    category: 'math'
  },
  {
    id: '5',
    name: 'Grammar Guru',
    description: 'Excellent grammar skills',
    icon: '✍️',
    earnedAt: new Date(),
    category: 'english'
  }
];